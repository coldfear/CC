# Eliminate Game

使用cocos creator练手的一个三消类游戏，欢迎fork。

cocos creator 使用版本 1.11
